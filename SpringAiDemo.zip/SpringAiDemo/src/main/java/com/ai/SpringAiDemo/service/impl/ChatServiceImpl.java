package com.ai.SpringAiDemo.service.impl;

import com.ai.SpringAiDemo.service.ChatService;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.model.Media;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.multipart.MultipartFile;

import java.net.URI;

@Service
public class ChatServiceImpl implements ChatService {

    private final ChatClient chatClient;

    public ChatServiceImpl(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    @Override
    public String generateResponse(String message) {
        var response = chatClient.prompt()
                .user(message)
                .call()
                .content();
        return response != null ? response : "No response generated.";
    }

    @Override
    public String askExpert(String subject, String question) {
        var systemPrompt = String.format("You are an expert tutor in %s. Provide a clear, concise, and helpful answer.", subject);

        var response = chatClient.prompt()
                .system(systemPrompt)
                .user(question)
                .call()
                .content();

        return response != null ? response : "No answer generated.";
    }

    @Override
    public String analyzeImage(MultipartFile file, String prompt) {
        try {
            var mimeType = file.getContentType() != null ?
                    MimeTypeUtils.parseMimeType(file.getContentType()) : MimeTypeUtils.IMAGE_JPEG;
            var resource = new ByteArrayResource(file.getBytes());
            var media = new Media(mimeType, resource);

            var userPromptText = (prompt != null && !prompt.isBlank()) ? prompt : "Describe what you see in this image in detail.";

            var response = chatClient.prompt()
                    .user(userSpec -> userSpec.text(userPromptText).media(media))
                    .call()
                    .content();

            return response != null ? response : "Could not analyze the image.";
        } catch (Exception e) {
            return "Error analyzing image: " + e.getMessage();
        }
    }

    @Override
    public String analyzeImageUrl(String imageUrl, String prompt) {
        try {
            var urlResource = new UrlResource(new URI(imageUrl));
            var media = new Media(MimeTypeUtils.IMAGE_JPEG, urlResource);

            var userPromptText = (prompt != null && !prompt.isBlank()) ? prompt : "Describe what you see in this image in detail.";

            var response = chatClient.prompt()
                    .user(userSpec -> userSpec.text(userPromptText).media(media))
                    .call()
                    .content();

            return response != null ? response : "Could not analyze the image from URL.";
        } catch (Exception e) {
            return "Error analyzing image from URL: " + e.getMessage();
        }
    }

    @Override
    public java.util.Map<String, String> generateImageUrl(String prompt) {
        try {
            var systemPrompt = "You are an AI image prompt optimizer. Take the user input and refine it into a detailed, descriptive 1-2 sentence image generation prompt. Respond ONLY with the refined prompt, no extra text or quotes.";
            var enhancedPrompt = chatClient.prompt()
                    .system(systemPrompt)
                    .user(prompt)
                    .call()
                    .content();

            if (enhancedPrompt == null || enhancedPrompt.isBlank()) {
                enhancedPrompt = prompt;
            } else {
                enhancedPrompt = enhancedPrompt.trim().replaceAll("^\"|\"$", "");
            }

            var encodedPrompt = java.net.URLEncoder.encode(enhancedPrompt, java.nio.charset.StandardCharsets.UTF_8);
            var imageUrl = "https://image.pollinations.ai/prompt/" + encodedPrompt;

            return java.util.Map.of(
                    "originalPrompt", prompt,
                    "enhancedPrompt", enhancedPrompt,
                    "imageUrl", imageUrl
            );
        } catch (Exception e) {
            var encodedFallback = java.net.URLEncoder.encode(prompt, java.nio.charset.StandardCharsets.UTF_8);
            var fallbackUrl = "https://image.pollinations.ai/prompt/" + encodedFallback;
            return java.util.Map.of(
                    "originalPrompt", prompt,
                    "enhancedPrompt", prompt,
                    "imageUrl", fallbackUrl
            );
        }
    }
}