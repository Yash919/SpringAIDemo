package com.ai.SpringAiDemo.service;

import org.springframework.web.multipart.MultipartFile;

public interface ChatService {
    String generateResponse(String message);
    String askExpert(String subject, String question);
    String analyzeImage(MultipartFile file, String prompt);
    String analyzeImageUrl(String imageUrl, String prompt);
    java.util.Map<String, String> generateImageUrl(String prompt);
}


