package com.ai.SpringAiDemo.controller;

import com.ai.SpringAiDemo.service.ChatService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

@RestController
@RequestMapping("/api/ai")
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    /**
     * GET endpoint to generate AI responses using Gemini.
     * Example: http://localhost:8080/api/ai/generate?message=
     */
    @GetMapping("/generate")
    public Map<String, String> generate(
            @RequestParam(value = "message", defaultValue = "Tell me an interesting fact about space") String message) {

        var response = chatService.generateResponse(message);

        return Map.of(
                "prompt", message,
                "response", response
        );
    }

    /**
     * Custom persona/system prompt endpoint.
     * Example: http://localhost:8080/api/ai/ask-expert?subject=Java&question=What are Virtual Threads?
     */
    @GetMapping("/ask-expert")
    public Map<String, String> askExpert(
            @RequestParam String subject,
            @RequestParam String question) {

        var answer = chatService.askExpert(subject, question);

        return Map.of(
                "subject", subject,
                "question", question,
                "answer", answer
        );
    }

    /**
     * POST endpoint to upload and analyze an image using Gemini Flash Multimodal.
     * Example: curl -F "file=@image.jpg" -F "prompt=Describe this image" http://localhost:8080/api/ai/analyze-image
     */
    @PostMapping("/analyze-image")
    public Map<String, String> analyzeImage(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "prompt", defaultValue = "Describe what you see in this image in detail") String prompt) {

        var analysis = chatService.analyzeImage(file, prompt);

        return Map.of(
                "fileName", file.getOriginalFilename() != null ? file.getOriginalFilename() : "unknown",
                "prompt", prompt,
                "analysis", analysis
        );
    }

    /**
     * GET endpoint to analyze an image from a publicly accessible URL.
     * Example: http://localhost:8080/api/ai/analyze-image-url?imageUrl=https://example.com/sample.jpg
     */
    @GetMapping("/analyze-image-url")
    public Map<String, String> analyzeImageUrl(
            @RequestParam("imageUrl") String imageUrl,
            @RequestParam(value = "prompt", defaultValue = "Describe what you see in this image in detail") String prompt) {

        var analysis = chatService.analyzeImageUrl(imageUrl, prompt);

        return Map.of(
                "imageUrl", imageUrl,
                "prompt", prompt,
                "analysis", analysis
        );
    }

    /**
     * GET endpoint that generates an image URL based on user prompt.
     * Example: http://localhost:8080/api/ai/generate-image?prompt=anything_user_wants
     */
    @GetMapping("/generate-image")
    public Map<String, String> generateImage(
            @RequestParam("prompt") String prompt) {

        return chatService.generateImageUrl(prompt);
    }

    /**
     * GET endpoint that redirects directly to the generated image.
     * Example: http://localhost:8080/api/ai/generate-image-redirect?prompt=anything_user_wants
     */
    @GetMapping("/generate-image-redirect")
    public org.springframework.http.ResponseEntity<Void> generateImageRedirect(
            @RequestParam("prompt") String prompt) {

        var result = chatService.generateImageUrl(prompt);
        var imageUrl = result.get("imageUrl");

        return org.springframework.http.ResponseEntity
                .status(org.springframework.http.HttpStatus.FOUND)
                .location(java.net.URI.create(imageUrl))
                .build();
    }
}